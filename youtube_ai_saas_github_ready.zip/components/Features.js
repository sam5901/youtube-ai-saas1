export default function Features() {
  return (
    <section className="p-12 bg-white">
      <h2 className="text-3xl font-bold text-center mb-8">What You Get</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
        <div><h3 className="font-bold text-xl">Script Generator</h3><p>Fast, tone-matched scripts</p></div>
        <div><h3 className="font-bold text-xl">Title Optimizer</h3><p>CTR-boosted headline AI</p></div>
        <div><h3 className="font-bold text-xl">SEO Tags + Tips</h3><p>Reach and rank better</p></div>
      </div>
    </section>
  )
}