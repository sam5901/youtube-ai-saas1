export default function Hero() {
  return (
    <section className="text-center p-12 bg-black text-white">
      <h1 className="text-5xl font-bold">AI Assistant for YouTubers</h1>
      <p className="mt-4 text-xl">Scripts, Titles & Optimization in seconds.</p>
      <div className="mt-6">
        <button className="bg-white text-black px-6 py-2 rounded-xl font-semibold">Join Waitlist</button>
      </div>
    </section>
  )
}