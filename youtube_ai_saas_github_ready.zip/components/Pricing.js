export default function Pricing() {
  return (
    <section className="p-12 bg-white">
      <h2 className="text-3xl font-bold text-center mb-8">Pricing</h2>
      <div className="flex justify-center gap-8 flex-wrap">
        <div className="bg-gray-100 p-6 rounded-xl text-center w-72">
          <h3 className="text-xl font-bold">Free</h3>
          <p className="my-2">$0/month</p>
          <ul className="text-sm">
            <li>5 scripts/month</li>
            <li>Basic optimization</li>
          </ul>
        </div>
        <div className="bg-gray-800 text-white p-6 rounded-xl text-center w-72">
          <h3 className="text-xl font-bold">Pro</h3>
          <p className="my-2">$19/month</p>
          <ul className="text-sm">
            <li>Unlimited scripts</li>
            <li>CTR + SEO boosts</li>
            <li>Personalized suggestions</li>
          </ul>
        </div>
      </div>
    </section>
  )
}