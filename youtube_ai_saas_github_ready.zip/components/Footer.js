export default function Footer() {
  return (
    <footer className="bg-black text-white text-center p-6">
      <p>&copy; 2025 Your AI YouTube Assistant</p>
    </footer>
  )
}