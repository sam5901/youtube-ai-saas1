export default function Workflow() {
  return (
    <section className="p-12 bg-gray-100">
      <h2 className="text-3xl font-bold text-center mb-8">How It Works</h2>
      <ol className="list-decimal list-inside max-w-xl mx-auto text-lg space-y-2">
        <li>Type your video idea</li>
        <li>Choose script & title</li>
        <li>Optimize SEO + tags</li>
        <li>Export or publish</li>
      </ol>
    </section>
  )
}