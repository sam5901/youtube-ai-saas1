# YouTube AI SaaS

This is a React + Tailwind + Next.js landing page for a SaaS product that helps YouTubers (10k–500k subs) script, title, and optimize their videos using AI.

## 🚀 Features
- Hero CTA with waitlist
- Features overview
- Workflow steps
- Freemium + Pro pricing
- Clean responsive design

## 🛠 Getting Started

```bash
npm install
npm run dev
```

Then visit: http://localhost:3000

## 🌐 Deploy

Recommended: [Vercel](https://vercel.com) for instant deployment.